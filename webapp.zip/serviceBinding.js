function initModel() {
	var sUrl = "/hana/DoctorsApplication/xs/Services/DoctorList.xsodata/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}