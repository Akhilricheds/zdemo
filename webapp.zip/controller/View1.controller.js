sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("app.demo.controller.View1", {
		
		onInit: function(){
	/*	var Array1 = [];
		var AMDataModel = new sap.ui.model.json.JSONModel();
  var oModelAM = new sap.ui.model.odata.ODataModel(
         "/sap/opu/odata/IWBEP/GWSAMPLE_BASIC/",true);
          oModelAM.read("ProductSet",null,
              null,false,
              function(oData, repsonse){
            Array1 = oData.results;
              });

            //  Array1.AMList = AMList;
             // olength = Array1.length;
          AMDataModel.setData(Array1);
          this.getView().setModel(AMDataModel);
		}*/
			var Array1 = [];
		var AMDataModel = new sap.ui.model.json.JSONModel();
  var oModelAM = new sap.ui.model.odata.ODataModel(
         "/DoctorsApplication/xs/Services/DoctorList.xsodata/",true);
          oModelAM.read("DoctorList",null,
              null,false,
              function(oData, repsonse){
            Array1 = oData.results;
              });
			var AMList;
          Array1.AMList = AMList;
             // olength = Array1.length;
          AMDataModel.setData(Array1);
          this.getView().setModel(AMDataModel);
		}
	});
});